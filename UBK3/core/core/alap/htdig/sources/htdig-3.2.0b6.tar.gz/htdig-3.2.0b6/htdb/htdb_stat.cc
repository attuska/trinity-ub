// Part of the ht://Dig package   <http://www.htdig.org/>
// Copyright (c) 1999-2004 The ht://Dig Group
// For copyright details, see the file COPYING in your distribution
// or the GNU Library General Public License (LGPL) version 2 or later
// <http://www.gnu.org/copyleft/lgpl.html>
//
/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 1996, 1997, 1998, 1999
 *	Sleepycat Software.  All rights reserved.
 */

#include "db_config.h"
#include "htconfig.h"

#ifndef lint
static const char copyright[] =
"@(#) Copyright (c) 1996, 1997, 1998, 1999\n\
	Sleepycat Software Inc.  All rights reserved.\n";
static const char sccsid[] = "@(#)db_stat.c	11.2 (Sleepycat) 9/14/99";
#endif

#ifndef NO_SYSTEM_INCLUDES
#include <sys/types.h>

#if TIME_WITH_SYS_TIME
#include <sys/time.h>
#include <time.h>
#else
#if HAVE_SYS_TIME_H
#include <sys/time.h>
#else
#include <time.h>
#endif
#endif

#include <ctype.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef HAVE_GETOPT_H
#include <getopt.h>
#endif /* HAVE_GETOPT_H */
#endif

extern "C" {
#include "db_int.h"
#include "db_page.h"
#include "db_shash.h"
#include "lock.h"
#include "mp.h"
}

#include "WordDBInfo.h"
#include "WordDBCompress.h"
#include "WordContext.h"

#define	PCT(f, t, pgsize)						\
    ((t) == 0 ? 0 :							\
    (((double)(((t) * (pgsize)) - (f)) / ((t) * (pgsize))) * 100))

typedef enum { T_NOTSET, T_DB, T_ENV, T_LOCK, T_LOG, T_MPOOL, T_TXN } test_t;

int	 argcheck __P((char *, const char *));
int	 btree_stats __P((DB_ENV *, DB *));
int	 db_init __P((char *, test_t));
void	 dl __P((const char *, u_long));
void	 dl_bytes __P((const char *, u_long, u_long, u_long));
int	 env_stats __P((DB_ENV *));
int	 hash_stats __P((DB_ENV *, DB *));
int	 lock_ok __P((char *));
int	 lock_stats __P((DB_ENV *));
int	 log_stats __P((DB_ENV *));
int	 main __P((int, char *[]));
int	 mpool_ok __P((char *));
int	 mpool_stats __P((DB_ENV *));
void	 onint __P((int));
void	 prflags __P((u_int32_t, const FN *));
int	 queue_stats __P((DB_ENV *, DB *));
void	 siginit __P((void));
int	 txn_compare __P((const void *, const void *));
int	 txn_stats __P((DB_ENV *));
void	 usage __P((void));

DB_ENV	*dbenv;
int	 interrupted;
char	*stats_internal;
const char
	*progname = "htdb_stat";				/* Program name. */

int
main(int argc, char *argv[])
{
	extern char *optarg;
	extern int optind;
	DB *dbp;
	test_t ttype;
	int ch, d_close, e_close, exitval, Nflag, ret;
	char *db, *home, *subdb;
	int compress = 0;
	int wordlist = 0;
	Configuration *config = 0;

	dbp = NULL;
	ttype = T_NOTSET;
	d_close = e_close = exitval = Nflag = 0;
	db = home = subdb = NULL;
	while ((ch = getopt(argc, argv, "C:cd:eh:lM:mNs:tzW")) != EOF)
		switch (ch) {
		case 'C':
			ttype = T_LOCK;
			if (!argcheck(stats_internal = optarg, "Acflmo"))
				usage();
			break;
		case 'c':
			ttype = T_LOCK;
			break;
		case 'd':
			db = optarg;
			ttype = T_DB;
			break;
		case 'e':
			ttype = T_ENV;
			break;
		case 'h':
			home = optarg;
			break;
		case 'l':
			ttype = T_LOG;
			break;
		case 'M':
			ttype = T_MPOOL;
			if (!argcheck(stats_internal = optarg, "Ahlm"))
				usage();
			break;
		case 'm':
			ttype = T_MPOOL;
			break;
		case 'N':
			Nflag = 1;
			break;
		case 's':
			subdb = optarg;
			ttype = T_DB;
			break;
		case 't':
			ttype = T_TXN;
			break;
		case 'z':
			compress = DB_COMPRESS;
			break;
		case 'W':
			wordlist = 1;
			break;
		case '?':
		default:
			usage();
		}
	argc -= optind;
	argv += optind;

	switch (ttype) {
	case T_DB:
		if (db == NULL)
			usage();
		break;
	case T_NOTSET:
		usage();
		/* NOTREACHED */
	default:
		break;
	}

	/* Handle possible interruptions. */
	siginit();

	if(wordlist && compress) {
	  static ConfigDefaults defaults[] = {
	    { "wordlist_wordkey_description", "Word/DocID 32/Flag 8/Location 16"},
	    { "wordlist_env_skip", "true"},
	    { 0, 0, 0 }
	  };
	  config = WordContext::Initialize(defaults);
	}

	/*
	 * Create an environment object and initialize it for error
	 * reporting.
	 */
	if ((ret = CDB_db_env_create(&dbenv, 0)) != 0) {
	  fprintf(stderr,
		  "%s: CDB_db_env_create: %s\n", progname, CDB_db_strerror(ret));
	  exit (1);
	}

	dbenv->set_errfile(dbenv, stderr);
	dbenv->set_errpfx(dbenv, progname);
	if(wordlist && compress) dbenv->mp_cmpr_info = (new WordDBCompress)->CmprInfo();

	/* Optionally turn mutexes and the panic checks off. */
	if (Nflag) {
	  if ((ret = dbenv->set_mutexlocks(dbenv, 0)) != 0) {
	    dbenv->err(dbenv, ret, "set_mutexlocks");
	    goto shutdown;
	  }
	  if ((ret = dbenv->set_panic(dbenv, 0)) != 0) {
	    dbenv->err(dbenv, ret, "set_panic");
	    goto shutdown;
	  }
	}

	/* Initialize the environment. */
	if (db_init(home, ttype) != 0)
	  goto shutdown;

	e_close = 1;

	switch (ttype) {
	case T_DB:
		/* Create the DB object and open the file. */
		if ((ret = CDB_db_create(&dbp, dbenv, 0)) != 0) {
			dbenv->err(dbenv, ret, "CDB_db_create");
			goto shutdown;
		}
		if ((ret =
		    dbp->open(dbp, db, subdb, DB_UNKNOWN, (DB_RDONLY | compress), 0)) != 0) {
			dbp->err(dbp, ret, "open: %s", db);
			goto shutdown;
		}
		d_close = 1;
		switch (dbp->type) {
		case DB_BTREE:
		case DB_RECNO:
			if (btree_stats(dbenv, dbp))
				goto shutdown;
			break;
		case DB_HASH:
			if (hash_stats(dbenv, dbp))
				goto shutdown;
			break;
		case DB_QUEUE:
			if (queue_stats(dbenv, dbp))
				goto shutdown;
			break;
		case DB_UNKNOWN:
			abort();		/* Impossible. */
			/* NOTREACHED */
		}
		break;
	case T_ENV:
		if (env_stats(dbenv))
			exitval = 1;
		break;
	case T_LOCK:
		if (lock_stats(dbenv))
			exitval = 1;
		break;
	case T_LOG:
		if (log_stats(dbenv))
			exitval = 1;
		break;
	case T_MPOOL:
		if (mpool_stats(dbenv))
			exitval = 1;
		break;
	case T_TXN:
		if (txn_stats(dbenv))
			exitval = 1;
		break;
	case T_NOTSET:
		abort();			/* Impossible. */
		/* NOTREACHED */
	}

	if (0) {
shutdown:	exitval = 1;
	}
	if (d_close && (ret = dbp->close(dbp, 0)) != 0) {
		exitval = 1;
		dbp->err(dbp, ret, "close");
	}
	if (e_close && (ret = dbenv->close(dbenv, 0)) != 0) {
		exitval = 1;
		fprintf(stderr,
		    "%s: dbenv->close: %s\n", progname, CDB_db_strerror(ret));
	}

	if (interrupted) {
		(void)signal(interrupted, SIG_DFL);
		(void)raise(interrupted);
		/* NOTREACHED */
	}

	if(config) {
	  WordContext::Finish();
	  delete config;
	}

	return (exitval);
}

/*
 * env_stats --
 *	Display environment statistics.
 */
int
env_stats(DB_ENV *dbenvp)
{
	REGENV renv;
	REGION *rp, regs[1024];
	int n, ret;
	const char *lable;

	n = sizeof(regs) / sizeof(regs[0]);
	if ((ret = CDB___db_e_stat(dbenvp, &renv, regs, &n)) != 0)  {
		dbenvp->err(dbenvp, ret, "CDB___db_e_stat");
		return (1);
	}

	printf("%d.%d.%d\tEnvironment version.\n",
	    renv.majver, renv.minver, renv.patch);
	printf("%lx\tMagic number.\n", (u_long)renv.magic);
	printf("%d\tPanic value.\n", renv.panic);

	/* Adjust the reference count for us... */
	printf("%d\tReferences.\n", renv.refcnt - 1);

	dl("Locks granted without waiting.\n",
	    (u_long)renv.mutex.mutex_set_nowait);
	dl("Locks granted after waiting.\n",
	    (u_long)renv.mutex.mutex_set_wait);

	while (n > 0) {
		printf("%s\n", DB_LINE);
		rp = &regs[--n];
		switch (rp->id) {
		case REG_ID_ENV:
			lable = "Environment";
			break;
		case REG_ID_LOCK:
			lable = "Lock";
			break;
		case REG_ID_LOG:
			lable = "Log";
			break;
		case REG_ID_MPOOL:
			lable = "Mpool";
			break;
		case REG_ID_TXN:
			lable = "Txn";
			break;
		default:
			lable = "Unknown";
			break;
		}
		printf("%s Region: %d.\n", lable, rp->id);
		dl_bytes("Size.\n", (u_long)0, (u_long)0, (u_long)rp->size);
		printf("%d\tSegment ID.\n", rp->segid);
		dl("Locks granted without waiting.\n",
		    (u_long)rp->mutex.mutex_set_nowait);
		dl("Locks granted after waiting.\n",
		    (u_long)rp->mutex.mutex_set_wait);
	}

	return (0);
}

/*
 * btree_stats --
 *	Display btree/recno statistics.
 */
int
btree_stats(DB_ENV *dbenvp, DB *dbp)
{
	static const FN fn[] = {
		{ BTM_DUP,	"duplicates" },
		{ BTM_FIXEDLEN,	"fixed-length" },
		{ BTM_RECNO,	"recno" },
		{ BTM_RECNUM,	"record-numbers" },
		{ BTM_RENUMBER,	"renumber" },
		{ BTM_SUBDB,	"subdatabases" },
		{ 0,		NULL }
	};
	DB_BTREE_STAT *sp;
	int ret;

	COMPQUIET(dbenvp, NULL);

	if ((ret = dbp->stat(dbp, &sp, NULL, 0)) != 0) {
		dbp->err(dbp, ret, "dbp->stat");
		return (1);
	}

	printf("%lx\tBtree magic number.\n", (u_long)sp->bt_magic);
	printf("%lu\tBtree version number.\n", (u_long)sp->bt_version);
	prflags(sp->bt_metaflags, fn);
	if (dbp->type == DB_BTREE) {
#ifdef NOT_IMPLEMENTED
		dl("Maximum keys per-page.\n", (u_long)sp->bt_maxkey);
#endif
		dl("Minimum keys per-page.\n", (u_long)sp->bt_minkey);
	}
	if (dbp->type == DB_RECNO) {
		dl("Fixed-length record size.\n", (u_long)sp->bt_re_len);
		if (isprint(sp->bt_re_pad))
			printf("%c\tFixed-length record pad.\n",
			    (int)sp->bt_re_pad);
		else
			printf("0x%x\tFixed-length record pad.\n",
			    (int)sp->bt_re_pad);
	}
	dl("Underlying database page size.\n", (u_long)sp->bt_pagesize);
	dl("Number of levels in the tree.\n", (u_long)sp->bt_levels);
	dl("Number of keys in the tree.\n", (u_long)sp->bt_nrecs);

	dl("Number of tree internal pages.\n", (u_long)sp->bt_int_pg);
	dl("Number of bytes free in tree internal pages",
	    (u_long)sp->bt_int_pgfree);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->bt_int_pgfree, sp->bt_int_pg, sp->bt_pagesize));

	dl("Number of tree leaf pages.\n", (u_long)sp->bt_leaf_pg);
	dl("Number of bytes free in tree leaf pages",
	    (u_long)sp->bt_leaf_pgfree);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->bt_leaf_pgfree, sp->bt_leaf_pg, sp->bt_pagesize));

	dl("Number of tree duplicate pages.\n", (u_long)sp->bt_dup_pg);
	dl("Number of bytes free in tree duplicate pages",
	    (u_long)sp->bt_dup_pgfree);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->bt_dup_pgfree, sp->bt_dup_pg, sp->bt_pagesize));

	dl("Number of tree overflow pages.\n", (u_long)sp->bt_over_pg);
	dl("Number of bytes free in tree overflow pages",
	    (u_long)sp->bt_over_pgfree);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->bt_over_pgfree, sp->bt_over_pg, sp->bt_pagesize));

	dl("Number of pages on the free list.\n", (u_long)sp->bt_free);

	free(sp);

	return (0);
}

/*
 * hash_stats --
 *	Display hash statistics.
 */
int
hash_stats(DB_ENV *dbenvp, DB *dbp)
{
	static const FN fn[] = {
		{ DB_HASH_DUP,	"duplicates" },
		{ DB_HASH_SUBDB,"subdatabases" },
		{ 0,		NULL }
	};
	DB_HASH_STAT *sp;
	int ret;

	COMPQUIET(dbenvp, NULL);

	if ((ret = dbp->stat(dbp, &sp, NULL, 0)) != 0) {
		dbp->err(dbp, ret, "dbp->stat");
		return (1);
	}

	printf("%lx\tHash magic number.\n", (u_long)sp->hash_magic);
	printf("%lu\tHash version number.\n", (u_long)sp->hash_version);
	prflags(sp->hash_metaflags, fn);
	dl("Underlying database page size.\n", (u_long)sp->hash_pagesize);
	dl("Number of keys in the database.\n", (u_long)sp->hash_nrecs);

	dl("Number of hash buckets.\n", (u_long)sp->hash_buckets);
	dl("Number of bytes free on bucket pages", (u_long)sp->hash_bfree);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->hash_bfree, sp->hash_buckets, sp->hash_pagesize));

	dl("Number of overflow pages.\n", (u_long)sp->hash_bigpages);
	dl("Number of bytes free in overflow pages",
	    (u_long)sp->hash_big_bfree);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->hash_big_bfree, sp->hash_bigpages, sp->hash_pagesize));

	dl("Number of bucket overflow pages.\n", (u_long)sp->hash_overflows);
	dl("Number of bytes free in bucket overflow pages",
	    (u_long)sp->hash_ovfl_free);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->hash_ovfl_free, sp->hash_overflows, sp->hash_pagesize));

	dl("Number of duplicate pages.\n", (u_long)sp->hash_dup);
	dl("Number of bytes free in duplicate pages",
	    (u_long)sp->hash_dup_free);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->hash_dup_free, sp->hash_dup, sp->hash_pagesize));

	dl("Number of pages on the free list.\n", (u_long)sp->hash_free);

	return (0);
}

/*
 * queue_stats --
 *	Display queue statistics.
 */
int
queue_stats(DB_ENV *dbenvp, DB *dbp)
{
	DB_QUEUE_STAT *sp;
	int ret;

	COMPQUIET(dbenvp, NULL);

	if ((ret = dbp->stat(dbp, &sp, NULL, 0)) != 0) {
		dbp->err(dbp, ret, "dbp->stat");
		return (1);
	}

	printf("%lx\tQueue magic number.\n", (u_long)sp->qs_magic);
	printf("%lu\tQueue version number.\n", (u_long)sp->qs_version);
	dl("Fixed-length record size.\n", (u_long)sp->qs_re_len);
	if (isprint(sp->qs_re_pad))
		printf("%c\tFixed-length record pad.\n", (int)sp->qs_re_pad);
	else
		printf("0x%x\tFixed-length record pad.\n", (int)sp->qs_re_pad);
	dl("Underlying tree page size.\n", (u_long)sp->qs_pagesize);
	dl("Number of records in the database.\n", (u_long)sp->qs_nrecs);
	dl("Number of database pages.\n", (u_long)sp->qs_pages);
	dl("Number of bytes free in database pages", (u_long)sp->qs_pgfree);
	printf(" (%.0f%% ff).\n",
	    PCT(sp->qs_pgfree, sp->qs_pages, sp->qs_pagesize));
	printf("%lu\tFirst undeleted record.\n", (u_long)sp->qs_first_recno);
	printf(
	    "%lu\tLast allocated record number.\n", (u_long)sp->qs_cur_recno);
	printf("%lu\tStart offset.\n", (u_long)sp->qs_start);

	return (0);
}

/*
 * lock_stats --
 *	Display lock statistics.
 */
int
lock_stats(DB_ENV *dbenvp)
{
	DB_LOCK_STAT *sp;
	int ret;

	if (stats_internal != NULL) {
		CDB___lock_dump_region(dbenvp, stats_internal, stdout);
		return (0);
	}

	if ((ret = CDB_lock_stat(dbenvp, &sp, NULL)) != 0) {
		dbenvp->err(dbenvp, ret, NULL);
		return (1);
	}

	dl("Last allocated locker ID.\n", (u_long)sp->st_lastid);
	dl("Number of lock modes.\n", (u_long)sp->st_nmodes);
	dl("Maximum number of locks possible.\n", (u_long)sp->st_maxlocks);
	dl("Current lockers.\n", (u_long)sp->st_nlockers);
	dl("Maximum current lockers.\n", (u_long)sp->st_nlockers);
	dl("Number of lock requests.\n", (u_long)sp->st_nrequests);
	dl("Number of lock releases.\n", (u_long)sp->st_nreleases);
	dl("Number of lock conflicts.\n", (u_long)sp->st_nconflicts);
	dl("Number of deadlocks.\n", (u_long)sp->st_ndeadlocks);
	dl_bytes("Lock region size.\n",
	    (u_long)0, (u_long)0, (u_long)sp->st_regsize);
	dl("The number of region locks granted without waiting.\n",
	    (u_long)sp->st_region_nowait);
	dl("The number of region locks granted after waiting.\n",
	    (u_long)sp->st_region_wait);

	return (0);
}

/*
 * log_stats --
 *	Display log statistics.
 */
int
log_stats(DB_ENV *dbenvp)
{
	DB_LOG_STAT *sp;
	int ret;

	if ((ret = CDB_log_stat(dbenvp, &sp, NULL)) != 0) {
		dbenvp->err(dbenvp, ret, NULL);
		return (1);
	}

	printf("%lx\tLog magic number.\n", (u_long)sp->st_magic);
	printf("%lu\tLog version number.\n", (u_long)sp->st_version);
	dl_bytes("Log region size.\n",
	    (u_long)0, (u_long)0, (u_long)sp->st_regsize);
	dl_bytes("Log record cache size.\n",
	    (u_long)0, (u_long)0, (u_long)sp->st_lg_bsize);
	printf("%#o\tLog file mode.\n", sp->st_mode);
	if (sp->st_lg_max % MEGABYTE == 0)
		printf("%luMb\tLog file size.\n",
		    (u_long)sp->st_lg_max / MEGABYTE);
	else if (sp->st_lg_max % 1024 == 0)
		printf("%luKb\tLog file size.\n", (u_long)sp->st_lg_max / 1024);
	else
		printf("%lu\tLog file size.\n", (u_long)sp->st_lg_max);
	dl_bytes("Log bytes written.\n",
	    (u_long)0, (u_long)sp->st_w_mbytes, (u_long)sp->st_w_bytes);
	dl_bytes("Log bytes written since last checkpoint.\n",
	    (u_long)0, (u_long)sp->st_wc_mbytes, (u_long)sp->st_wc_bytes);
	dl("Total log file writes.\n", (u_long)sp->st_wcount);
	dl("Total log file write due to overflow.\n",
	    (u_long)sp->st_wcount_fill);
	dl("Total log file flushes.\n", (u_long)sp->st_scount);
	printf("%lu\tCurrent log file number.\n", (u_long)sp->st_cur_file);
	printf("%lu\tCurrent log file offset.\n", (u_long)sp->st_cur_offset);
	dl("The number of region locks granted without waiting.\n",
	    (u_long)sp->st_region_nowait);
	dl("The number of region locks granted after waiting.\n",
	    (u_long)sp->st_region_wait);

	return (0);
}

/*
 * mpool_stats --
 *	Display mpool statistics.
 */
int
mpool_stats(DB_ENV *dbenvp)
{
	DB_MPOOL_FSTAT **fsp;
	DB_MPOOL_STAT *gsp;
	int ret;

	if (stats_internal != NULL) {
		CDB___memp_dump_region(dbenvp, stats_internal, stdout);
		return (1);
	}

	if ((ret = CDB_memp_stat(dbenvp, &gsp, &fsp, NULL)) != 0) {
		dbenvp->err(dbenvp, ret, NULL);
		return (1);
	}

	dl("Pool region size.\n", (u_long)gsp->st_regsize);
	dl_bytes("Cache size.\n",
	    (u_long)gsp->st_gbytes, (u_long)0, (u_long)gsp->st_bytes);
	dl("Requested pages found in the cache", (u_long)gsp->st_cache_hit);
	if (gsp->st_cache_hit + gsp->st_cache_miss != 0)
		printf(" (%.0f%%)", ((double)gsp->st_cache_hit /
		    (gsp->st_cache_hit + gsp->st_cache_miss)) * 100);
	printf(".\n");
	dl("Requested pages mapped into the process' address space.\n",
	    (u_long)gsp->st_map);
	dl("Requested pages not found in the cache.\n",
	    (u_long)gsp->st_cache_miss);
	dl("Pages created in the cache.\n", (u_long)gsp->st_page_create);
	dl("Pages read into the cache.\n", (u_long)gsp->st_page_in);
	dl("Pages written from the cache to the backing file.\n",
	    (u_long)gsp->st_page_out);
	dl("Clean pages forced from the cache.\n",
	    (u_long)gsp->st_ro_evict);
	dl("Dirty pages forced from the cache.\n",
	    (u_long)gsp->st_rw_evict);
	dl("Dirty buffers written by trickle-sync thread.\n",
	    (u_long)gsp->st_page_trickle);
	dl("Current clean buffer count.\n",
	    (u_long)gsp->st_page_clean);
	dl("Current dirty buffer count.\n",
	    (u_long)gsp->st_page_dirty);
	dl("Number of hash buckets used for page location.\n",
	    (u_long)gsp->st_hash_buckets);
	dl("Total number of times hash chains searched for a page.\n",
	    (u_long)gsp->st_hash_searches);
	dl("The longest hash chain searched for a page.\n",
	    (u_long)gsp->st_hash_longest);
	dl("Total number of hash buckets examined for page location.\n",
	    (u_long)gsp->st_hash_examined);
	dl("The number of region locks granted without waiting.\n",
	    (u_long)gsp->st_region_nowait);
	dl("The number of region locks granted after waiting.\n",
	    (u_long)gsp->st_region_wait);

	for (; fsp != NULL && *fsp != NULL; ++fsp) {
		printf("%s\n", DB_LINE);
		printf("Pool File: %s\n", (*fsp)->file_name);
		dl("Page size.\n", (u_long)(*fsp)->st_pagesize);
		dl("Requested pages found in the cache",
		    (u_long)(*fsp)->st_cache_hit);
		if ((*fsp)->st_cache_hit + (*fsp)->st_cache_miss != 0)
			printf(" (%.0f%%)", ((double)(*fsp)->st_cache_hit /
			    ((*fsp)->st_cache_hit + (*fsp)->st_cache_miss)) *
			    100);
		printf(".\n");
		dl("Requested pages mapped into the process' address space.\n",
		    (u_long)(*fsp)->st_map);
		dl("Requested pages not found in the cache.\n",
		    (u_long)(*fsp)->st_cache_miss);
		dl("Pages created in the cache.\n",
		    (u_long)(*fsp)->st_page_create);
		dl("Pages read into the cache.\n",
		    (u_long)(*fsp)->st_page_in);
		dl("Pages written from the cache to the backing file.\n",
		    (u_long)(*fsp)->st_page_out);
	}

	return (0);
}

/*
 * txn_stats --
 *	Display transaction statistics.
 */
int
txn_stats(DB_ENV *dbenvp)
{
	DB_TXN_STAT *sp;
	u_int32_t i;
	int ret;
	const char *p;

	if ((ret = CDB_txn_stat(dbenvp, &sp, NULL)) != 0) {
		dbenvp->err(dbenvp, ret, NULL);
		return (1);
	}

	p = sp->st_last_ckp.file == 0 ?
	    "No checkpoint LSN." : "File/offset for last checkpoint LSN.";
	printf("%lu/%lu\t%s\n",
	    (u_long)sp->st_last_ckp.file, (u_long)sp->st_last_ckp.offset, p);
	p = sp->st_pending_ckp.file == 0 ?
	    "No pending checkpoint LSN." :
	    "File/offset for last pending checkpoint LSN.";
	printf("%lu/%lu\t%s\n",
	    (u_long)sp->st_pending_ckp.file,
	    (u_long)sp->st_pending_ckp.offset, p);
	if (sp->st_time_ckp == 0)
		printf("0\tNo checkpoint timestamp.\n");
	else
		printf("%.24s\tCheckpoint timestamp.\n",
		    ctime(&sp->st_time_ckp));
	printf("%lx\tLast transaction ID allocated.\n",
	    (u_long)sp->st_last_txnid);
	dl("Maximum number of active transactions possible.\n",
	    (u_long)sp->st_maxtxns);
	dl("Active transactions.\n", (u_long)sp->st_nactive);
	dl("Maximum active transactions.\n", (u_long)sp->st_maxnactive);
	dl("Number of transactions begun.\n", (u_long)sp->st_nbegins);
	dl("Number of transactions aborted.\n", (u_long)sp->st_naborts);
	dl("Number of transactions committed.\n", (u_long)sp->st_ncommits);
	dl_bytes("Transaction region size.\n",
	    (u_long)0, (u_long)0, (u_long)sp->st_regsize);
	dl("The number of region locks granted without waiting.\n",
	    (u_long)sp->st_region_nowait);
	dl("The number of region locks granted after waiting.\n",
	    (u_long)sp->st_region_wait);
	qsort(sp->st_txnarray,
	    sp->st_nactive, sizeof(sp->st_txnarray[0]), txn_compare);
	for (i = 0; i < sp->st_nactive; ++i)
		printf("\tid: %lx; initial LSN file/offest %lu/%lu\n",
		    (u_long)sp->st_txnarray[i].txnid,
		    (u_long)sp->st_txnarray[i].lsn.file,
		    (u_long)sp->st_txnarray[i].lsn.offset);

	return (0);
}

int
txn_compare(const void *a1, const void *b1)
{
	const DB_TXN_ACTIVE *a, *b;

	a = (DB_TXN_ACTIVE*)a1;
	b = (DB_TXN_ACTIVE*)b1;

	if (a->txnid > b->txnid)
		return (1);
	if (a->txnid < b->txnid)
		return (-1);
	return (0);
}

/*
 * dl --
 *	Display a big value.
 */
void
dl(const char *msg, u_long value)
{
	/*
	 * Two formats: if less than 10 million, display as the number, if
	 * greater than 10 million display as ###M.
	 */
	if (value < 10000000)
		printf("%lu\t%s", value, msg);
	else
		printf("%luM\t%s", value / 1000000, msg);
}

/*
 * dl_bytes --
 *	Display a big number of bytes.
 */
void
dl_bytes(const char *msg, u_long gbytes, u_long mbytes, u_long bytes)
{
	const char *sep;

	while (bytes > MEGABYTE) {
		++mbytes;
		bytes -= MEGABYTE;
	}
	while (mbytes > GIGABYTE / MEGABYTE) {
		++gbytes;
		--mbytes;
	}

	sep = "";
	if (gbytes > 0) {
		printf("%luGB", gbytes);
		sep = " ";
	}
	if (mbytes > 0) {
		printf("%s%luMB", sep, bytes);
		sep = " ";
	}
	if (bytes > 1024) {
		printf("%s%luKB", sep, bytes / 1024);
		bytes %= 1024;
		sep = " ";
	}
	if (bytes > 0)
		printf("%s%lu", sep, bytes);
	printf("\t%s", msg);
}

/*
 * prflags --
 *	Print out flag values.
 */
void
prflags(u_int32_t flags, const FN *fnp)
{
	const char *sep;

	sep = "\t";
	printf("Flags:");
	for (; fnp->mask != 0; ++fnp)
		if (fnp->mask & flags) {
			printf("%s%s", sep, fnp->name);
			sep = ", ";
		}
	printf("\n");
}

/*
 * db_init --
 *	Initialize the environment.
 */
int
db_init(char *home, test_t ttype)
{
	u_int32_t flags;
	int ret;

	/*
	 * Try and use the shared memory pool region when reporting statistics
	 * on the DB databases, so our information is as up-to-date as possible,
	 * even if the mpool cache hasn't been flushed.
	 */
	flags = DB_USE_ENVIRON;
	switch (ttype) {
	case T_ENV:
		break;
	case T_DB:
	case T_MPOOL:
		LF_SET(DB_INIT_MPOOL);
		break;
	case T_LOCK:
		LF_SET(DB_INIT_LOCK);
		break;
	case T_LOG:
		LF_SET(DB_INIT_LOG);
		break;
	case T_TXN:
		LF_SET(DB_INIT_TXN);
		break;
	case T_NOTSET:
		abort();
		/* NOTREACHED */
	}

	/*
	 * If that fails, and we're trying to look at a shared region, it's
	 * a hard failure.
	 */
	if ((ret = dbenv->open(dbenv, home, NULL, flags, 0)) == 0)
		return (0);
	if (ttype != T_DB) {
		dbenv->err(dbenv, ret, "open");
		return (1);
	}

	/*
	 * We're trying to look at a database.
	 *
	 * An environment is required because we may be trying to look at
	 * databases in directories other than the current one.  We could
	 * avoid using an environment iff the -h option wasn't specified,
	 * but that seems like more work than it's worth.
	 *
	 *
	 * No environment exists (or, at least no environment that includes
	 * an mpool region exists).  Create one, but make it private so that
	 * no files are actually created.
	 */
	LF_SET(DB_CREATE | DB_PRIVATE);
	if ((ret = dbenv->open(dbenv, home, NULL, flags, 0)) == 0)
		return (0);

	/* An environment is required. */
	dbenv->err(dbenv, ret, "open");
	return (1);
}

/*
 * argcheck --
 *	Return if argument flags are okay.
 */
int
argcheck(char *arg, const char *ok_args)
{
	for (; *arg != '\0'; ++arg)
		if (strchr(ok_args, *arg) == NULL)
			return (0);
	return (1);
}

/*
 * siginit --
 *	Initialize the set of signals for which we want to clean up.
 *	Generally, we try not to leave the shared regions locked if
 *	we can.
 */
void
siginit()
{
#ifdef SIGHUP
	(void)signal(SIGHUP, onint);
#endif
	(void)signal(SIGINT, onint);
#ifdef SIGPIPE
	(void)signal(SIGPIPE, onint);
#endif
	(void)signal(SIGTERM, onint);
}

/*
 * onint --
 *	Interrupt signal handler.
 */
void
onint(int signo)
{
	if ((interrupted = signo) == 0)
		interrupted = SIGINT;
}

void
usage()
{
	fprintf(stderr,
"usage: htdb_stat [-celmNtzW] [-C Acflmo] [-d file [-s file]] [-h home] [-M Ahlm]\n");
	exit (1);
}
