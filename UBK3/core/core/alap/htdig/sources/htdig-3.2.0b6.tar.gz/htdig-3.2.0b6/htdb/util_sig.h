#ifndef UTIL_SIG_H
#define UTIL_SIG_H

void __db_util_siginit();
int __db_util_interrupted();
void __db_util_sigresend();
#endif /* UTIL_SIG_H */
